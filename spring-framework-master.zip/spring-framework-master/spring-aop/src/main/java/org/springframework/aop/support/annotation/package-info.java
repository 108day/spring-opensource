/**
 * Annotation support for AOP pointcuts.
 */
@NonNullApi
@NonNullFields
package org.springframework.aop.support.annotation;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
